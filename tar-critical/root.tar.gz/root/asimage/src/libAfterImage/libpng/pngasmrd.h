/* pngasmrd.h - assembler version of utilities to read a PNG file
 *
 * libpng 1.2.5 - October 3, 2002
 * For conditions of distribution and use, see copyright notice in png.h
 * Copyright (c) 2002 Glenn Randers-Pehrson
 *
 */

/* This file is obsolete in libpng-1.0.9 and later; its contents now appear
 * at the end of pngconf.h.
 */
