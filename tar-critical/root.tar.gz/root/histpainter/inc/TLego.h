// @(#)root/histpainter:$Name: v4-04-02g $:$Id: TLego.h,v 1.5 2002/07/04 17:04:33 brun Exp $
// Author: Rene Brun   26/12/94

#ifndef ROOT_TLego
#define ROOT_TLego


//////////////////////////////////////////////////////////////////////////
//                                                                      //
// TLego                                                                //
//                                                                      //
// This include provided only for back compatibility                    //
// The class TLego has been renamed TPainter3dAlgorithms                //
// Use TPainter3dAlgorithms.h instead                                   //
//                                                                      //
//////////////////////////////////////////////////////////////////////////


#include "TPainter3dAlgorithms.h"
typedef TPainter3dAlgorithms TLego;

#endif
