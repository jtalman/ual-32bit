#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class TAlien;
#pragma link C++ class TAlienResult;
#pragma link C++ class TAlienProof;
#pragma link C++ class TAlienFile;
#pragma link C++ class TAlienSystem; 

#endif
