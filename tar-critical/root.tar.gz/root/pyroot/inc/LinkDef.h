#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ class TPython;
#pragma link C++ class TPyReturn;
#pragma link C++ class PyROOT::TPyException;

#endif
