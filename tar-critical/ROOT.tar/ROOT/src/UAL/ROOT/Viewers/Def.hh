
#ifndef UAL_ROOT_DEF_HH
#define UAL_ROOT_DEF_HH

namespace UAL {

/**
   Collection of ROOT-based (http://root.cern.ch) accelerator-specific viewers.
 */

  namespace ROOT {
  }

}

#endif
